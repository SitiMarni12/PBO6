package com.macbook;

public interface VolumeControl {
    void increaseVolume();
    void decreaseVolume();
}